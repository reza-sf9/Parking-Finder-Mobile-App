package com.example.firebasep.DataModels

data class EmployeeModel (
    var empId: String,
    var empName: String,
    var empAge: String,
    var empSalary: String
)