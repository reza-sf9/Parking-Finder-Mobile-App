# Developed by : Reza Saadati Fard
# This code is for server-side of Mobile Project
# this file is used to detect parking slots and send the results to the database
# We are using different yolov8 models to detect cars in the parking lot


import cv2
import numpy as np
from ultralytics import YOLO
import pyrebase

## configuration of db
firebaseConfig = {
  "apiKey": "AIzaSyCLC34VHbyQ7Z07fCV6KaaIYvxbHOiOoVU",
  "authDomain": "fir-login2-1769c.firebaseapp.com",
  "databaseURL": "https://fir-login2-1769c-default-rtdb.firebaseio.com",
  "projectId": "fir-login2-1769c",
  "storageBucket": "fir-login2-1769c.appspot.com",
  "messagingSenderId": "185170403510",
  "appId": "1:185170403510:web:78205e68e7c81547d18617",
  "measurementId": "G-0M5CM06S0F"
}

videoStatus = 1 # 1 for local test video - 2 for live streaming from Iphone by using Iriun Webcam app
skip_time = 5 # seding 1 frame every X seconds


# initialize firebase
fb = pyrebase.initialize_app(firebaseConfig)
db = fb.database()

# function to process each parking slot
def process_parking_slot(frame, area, slot_name, xyxys, classes, class_name):
    car_class_index = 2  # Typically, in COCO dataset, 'car' class has an index of 2
    truck_class_index = 7  # Typically, in COCO dataset, 'truck' class has an index of 7
    buss_class_index = 5  # Typically, in COCO dataset, 'bus' class has an index of 5

    list_cars = []

    for i in range(len(classes)):
        # Check if the detected class is a car
        if classes[i] == car_class_index or classes[i] == truck_class_index or classes[i] == buss_class_index:
            x1, y1, x2, y2 = [int(coord) for coord in xyxys[i][:4]]
            cx, cy = (x1 + x2) // 2, (y1 + y2) // 2

            # Check if the car is within the specified parking area
            if cv2.pointPolygonTest(np.array(area, np.int32), (cx, cy), False) >= 0:
                list_cars.append(class_name[int(classes[i])])

    len_cars = len(list_cars)
    color = (0, 0, 255) if len_cars == 1 else (0, 255, 0)
    cv2.polylines(frame, [np.array(area, np.int32)], True, color, 2)
    cv2.putText(frame, slot_name, (area[0][0] - 50, area[0][1] - 10), cv2.FONT_HERSHEY_COMPLEX, 0.5, color, 1)

    if len_cars == 0:
        return 1
    elif len_cars == 1:
        return 0

model_n = 'yolov8n'
if model_n == 'yolov8n':
    model_yolo = YOLO('yolov8n.pt')
elif model_n == 'yolov8s':
    model_yolo = YOLO('yolov8s.pt')
elif model_n == 'yolov8m': # good model
    model_yolo = YOLO('yolov8m.pt')
elif model_n == 'yolov8l':
    model_yolo = YOLO('yolov8l.pt')
elif model_n == 'yolov8x':
    model_yolo = YOLO('yolov8x.pt')



window_name = model_n
# read the image
cv2.namedWindow(window_name)


# load test video
if videoStatus == 1:
    cap = cv2.VideoCapture('unity_test.mov')
 # get vidieo from camera
elif videoStatus == 2:
    cap = cv2.VideoCapture(1)


fps = int(cap.get(cv2.CAP_PROP_FPS))



areaB1 = [(1885, 157), (1909, 272), (1816, 277), (1770, 172)]
areaB2 = [(1757, 161), (1793, 264), (1677, 267), (1643, 149)]
areaB3 = [(1617, 134), (1656, 260), (1548, 260), (1513, 132)]
areaB4 = [(1494, 125), (1524, 254), (1418, 259), (1402, 137)]
areaB5 = [(1373, 132), (1399, 248), (1295, 247), (1288, 132)]
areaB6 = [(1261, 125), (1275, 246), (1176, 236), (1178, 120)]
areaB7 = [(1155, 120), (1155, 250), (1056, 239), (1068, 115)]
areaB8 = [(1057, 118), (1035, 245), (895, 231), (919, 114)]
areaB9 = [(819, 110), (787, 217), (689, 211), (739, 96)]
areaB10 = [(722, 92), (675, 207), (565, 202), (623, 78)]
areaB11 = [(607, 81), (555, 208), (461, 189), (527, 91)]
areaB12 = [(505, 91), (451, 192), (353, 183), (414, 77)]
areaB13 = [(392, 77), (335, 189), (236, 178), (324, 63)]
areaB14 = [(291, 66), (236, 170), (137, 164), (216, 64)]
areaB15 = [(194, 64), (118, 177), (50, 159), (124, 70)]



areaC1 = [(1670, 250), (1715, 407), (1577, 400), (1553, 258)]
areaC2 = [(1520, 243), (1562, 404), (1446, 408), (1421, 246)]
areaC3 = [(1403, 240), (1418, 401), (1297, 403), (1288, 230)]
areaC4 = [(1262, 220), (1277, 391), (1163, 391), (1166, 238)]
areaC5 = [(1145, 233), (1140, 375), (1023, 374), (1046, 226)]
areaC6 = [(1020, 221), (1005, 354), (881, 330), (906, 218)]
areaC7 = [(774, 225), (732, 342), (602, 322), (654, 210)]
areaC8 = [(642, 207), (592, 328), (496, 318), (565, 192)]
areaC9 = [(543, 192), (468, 337), (353, 323), (439, 180)]
areaC10 = [(419, 177), (333, 327), (236, 316), (317, 181)]
areaC11 = [(303, 181), (215, 326), (105, 304), (200, 175)]
areaC12 = [(187, 169), (81, 301), (7, 290), (66, 174)]


areaD1 =[(1289, 569), (1286, 787), (1128, 798), (1140, 565)]
areaD2 =[(784, 527), (721, 762), (545, 716), (638, 523)]

frame_skip = 30*skip_time # Skip every x frames
frame_count = 0
processed_frame = 0
while True:    
    ret, frame = cap.read()

    if not ret:
        break


    if frame_count % frame_skip == 0:
        processed_frame += 1

        # capture the frame from video to pass to the model for detection
        # frame = cv2.resize(frame, (1280, 720))


        # cv2.imshow(window_name, frame)

        run_model = True
        if run_model:

            # detect objects in the frame
            results = model_yolo.predict(frame)

            # print(results[0])

            # get rectanbles of detected objects
            boxes = results[0].boxes
            xyxys = boxes.xyxy
            classes = boxes.cls
            confidences = boxes.conf

            class_name = results[0].names



            # B1_avlbl = 0
            B1_avlbl = process_parking_slot(frame, areaB1, 'B1', xyxys, classes, class_name)
            B2_avlbl = process_parking_slot(frame, areaB2, 'B2', xyxys, classes, class_name)
            B3_avlbl = process_parking_slot(frame, areaB3, 'B3', xyxys, classes, class_name)
            B4_avlbl = process_parking_slot(frame, areaB4, 'B4', xyxys, classes, class_name)
            B5_avlbl = process_parking_slot(frame, areaB5, 'B5', xyxys, classes, class_name)
            B6_avlbl = process_parking_slot(frame, areaB6, 'B6', xyxys, classes, class_name)
            B7_avlbl = process_parking_slot(frame, areaB7, 'B7', xyxys, classes, class_name)
            B8_avlbl = process_parking_slot(frame, areaB8, 'B8', xyxys, classes, class_name)
            B9_avlbl = process_parking_slot(frame, areaB9, 'B9', xyxys, classes, class_name)
            B10_avlbl = process_parking_slot(frame, areaB10, 'B10', xyxys, classes, class_name)
            B11_avlbl = process_parking_slot(frame, areaB11, 'B11', xyxys, classes, class_name)
            B12_avlbl = process_parking_slot(frame, areaB12, 'B12', xyxys, classes, class_name)
            B13_avlbl = process_parking_slot(frame, areaB13, 'B13', xyxys, classes, class_name)
            B14_avlbl = process_parking_slot(frame, areaB14, 'B14', xyxys, classes, class_name)
            B15_avlbl = process_parking_slot(frame, areaB15, 'B15', xyxys, classes, class_name)


            C1_avlbl = process_parking_slot(frame, areaC1, 'C1', xyxys, classes, class_name)
            C2_avlbl = process_parking_slot(frame, areaC2, 'C2', xyxys, classes, class_name)
            C3_avlbl = process_parking_slot(frame, areaC3, 'C3', xyxys, classes, class_name)
            C4_avlbl = process_parking_slot(frame, areaC4, 'C4', xyxys, classes, class_name)
            C5_avlbl = process_parking_slot(frame, areaC5, 'C5', xyxys, classes, class_name)
            C6_avlbl = process_parking_slot(frame, areaC6, 'C6', xyxys, classes, class_name)
            C7_avlbl = process_parking_slot(frame, areaC7, 'C7', xyxys, classes, class_name)
            C8_avlbl = process_parking_slot(frame, areaC8, 'C8', xyxys, classes, class_name)
            C9_avlbl = process_parking_slot(frame, areaC9, 'C9', xyxys, classes, class_name)
            C10_avlbl = process_parking_slot(frame, areaC10, 'C10', xyxys, classes, class_name)
            C11_avlbl = process_parking_slot(frame, areaC11, 'C11', xyxys, classes, class_name)
            C12_avlbl = process_parking_slot(frame, areaC12, 'C12', xyxys, classes, class_name)
            # C13_avlbl = process_parking_slot(frame, areaC13, 'C13', xyxys, classes, class_name)
            # C14_avlbl = process_parking_slot(frame, areaC14, 'C14', xyxys, classes, class_name)
            C13_avlbl = 0
            C14_avlbl = 0

            D1_avlbl = process_parking_slot(frame, areaD1, 'D1', xyxys, classes, class_name)
            D2_avlbl = process_parking_slot(frame, areaD2, 'D2', xyxys, classes, class_name)

            # write the results to db

            tot_avlb = B1_avlbl + B2_avlbl + B3_avlbl + B4_avlbl + B5_avlbl + B6_avlbl + B7_avlbl + B8_avlbl + B9_avlbl \
                       + B10_avlbl + B11_avlbl + B12_avlbl + B13_avlbl + B14_avlbl + B15_avlbl + C1_avlbl + C2_avlbl \
                       + C3_avlbl + C4_avlbl + C5_avlbl + C6_avlbl + C7_avlbl + C8_avlbl + C9_avlbl + C10_avlbl + C11_avlbl \
                       + C12_avlbl + C13_avlbl + C14_avlbl + D1_avlbl + D2_avlbl

            db.child("parkingSlotUnity").child("B1").update({"status": B1_avlbl})
            db.child("parkingSlotUnity").child("B2").update({"status": B2_avlbl})
            db.child("parkingSlotUnity").child("B3").update({"status": B3_avlbl})
            db.child("parkingSlotUnity").child("B4").update({"status": B4_avlbl})
            db.child("parkingSlotUnity").child("B5").update({"status": B5_avlbl})
            db.child("parkingSlotUnity").child("B6").update({"status": B6_avlbl})
            db.child("parkingSlotUnity").child("B7").update({"status": B7_avlbl})
            db.child("parkingSlotUnity").child("B8").update({"status": B8_avlbl})
            db.child("parkingSlotUnity").child("B9").update({"status": B9_avlbl})
            db.child("parkingSlotUnity").child("B10").update({"status": B10_avlbl})
            db.child("parkingSlotUnity").child("B11").update({"status": B11_avlbl})
            db.child("parkingSlotUnity").child("B12").update({"status": B12_avlbl})
            db.child("parkingSlotUnity").child("B13").update({"status": B13_avlbl})
            db.child("parkingSlotUnity").child("B14").update({"status": B14_avlbl})
            db.child("parkingSlotUnity").child("B15").update({"status": B15_avlbl})

            db.child("parkingSlotUnity").child("C1").update({"status": C1_avlbl})
            db.child("parkingSlotUnity").child("C2").update({"status": C2_avlbl})
            db.child("parkingSlotUnity").child("C3").update({"status": C3_avlbl})
            db.child("parkingSlotUnity").child("C4").update({"status": C4_avlbl})
            db.child("parkingSlotUnity").child("C5").update({"status": C5_avlbl})
            db.child("parkingSlotUnity").child("C6").update({"status": C6_avlbl})
            db.child("parkingSlotUnity").child("C7").update({"status": C7_avlbl})
            db.child("parkingSlotUnity").child("C8").update({"status": C8_avlbl})
            db.child("parkingSlotUnity").child("C9").update({"status": C9_avlbl})
            db.child("parkingSlotUnity").child("C10").update({"status": C10_avlbl})
            db.child("parkingSlotUnity").child("C11").update({"status": C11_avlbl})
            db.child("parkingSlotUnity").child("C12").update({"status": C12_avlbl})
            db.child("parkingSlotUnity").child("C13").update({"status": C13_avlbl})
            db.child("parkingSlotUnity").child("C14").update({"status": C14_avlbl})

            db.child("parkingSlotUnity").child("D1").update({"status": D1_avlbl})
            db.child("parkingSlotUnity").child("D2").update({"status": D2_avlbl})

            db.child("parkingSlotUnity").child("Total").update({"number": tot_avlb})



        str_ = '%s: %d' % (model_n, processed_frame)
        cv2.imshow(str_, frame)

        u=1

    frame_count += 1
    if cv2.waitKey(1)&0xFF==27: # press ESC to exit
        break



cap.release()
cv2.destroyAllWindows()
#stream.stop()


