# Developed by Reza Saadati Fard
# Date: Dec, 2023
# this file is used to manage the database and creating the table in firebase for parking slots

import uuid
import pyrebase


firebaseConfig = {
  "apiKey": "AIzaSyCLC34VHbyQ7Z07fCV6KaaIYvxbHOiOoVU",
  "authDomain": "fir-login2-1769c.firebaseapp.com",
  "databaseURL": "https://fir-login2-1769c-default-rtdb.firebaseio.com",
  "projectId": "fir-login2-1769c",
  "storageBucket": "fir-login2-1769c.appspot.com",
  "messagingSenderId": "185170403510",
  "appId": "1:185170403510:web:78205e68e7c81547d18617",
  "measurementId": "G-0M5CM06S0F"
}

# fb = Firebase(firebaseConfig)

fb = pyrebase.initialize_app(firebaseConfig)

db = fb.database() # connect to firebase database

# data = {"parkingSlot": "C1", "status": 0, "longitude": 40.7128, "latitude": -74.006}
# db.push(data)

# creat code for database with table name parkingSlotUnity, values of parkingSlot, status, longitude, latitude C1-C20

# db.push(data)


# create db on the firebase
# Generate a unique ID for the user

add_user = False
if add_user:
  unique_id = str(uuid.uuid4())
  # Create user data
  user_data = {
      "type": "user",
      "email": "mmm@wpi.edu",
      "pass": "1234567",
      "name": "Reza Saadati",
      "phone": "1234567890",
      "carPlate": "123456",
      "carModel": "VW",
      "carColor": "White",
      "carYear": "2011",
      "EV": 0,
     "handicapped": 1
  }

  # Add user data with a unique ID
  db.child("Users").child(unique_id).set(user_data)




update_parking = True
if update_parking:
  db.child("parkingSlotUnity").child("A1").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A2").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A3").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A4").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A5").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A6").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A7").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A8").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A9").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A10").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A11").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A12").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A13").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A14").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("A15").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})

  db.child("parkingSlotUnity").child("B1").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B2").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B3").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B4").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B5").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B6").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B7").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B8").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B9").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B10").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B11").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B12").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B13").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B14").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("B15").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 1})


  db.child("parkingSlotUnity").child("C1").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C2").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C3").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C4").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C5").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C6").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C7").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C8").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C9").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C10").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C11").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C12").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C13").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C14").set({"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("C15").set({"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 1})

  db.child("parkingSlotUnity").child("D1").set(
    {"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 1, "handicapped": 0})
  db.child("parkingSlotUnity").child("D2").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 1, "handicapped": 0})
  db.child("parkingSlotUnity").child("D3").set(
    {"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 1, "handicapped": 0})
  db.child("parkingSlotUnity").child("D4").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 1, "handicapped": 0})
  db.child("parkingSlotUnity").child("D5").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D6").set(
    {"status": 1, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D7").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D8").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D9").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D10").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D11").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D12").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D13").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D14").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D11").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D12").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D13").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D14").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})
  db.child("parkingSlotUnity").child("D15").set(
    {"status": 0, "longitude": 40.7128, "latitude": -74.006, "EV": 0, "handicapped": 0})



  db.child("parkingSlotUnity").child("Total").set(
    {"number": 13})

# update
db.child("parkingSlotUnity").child("D1").update({"status": 0})

# push data to db



u=1
