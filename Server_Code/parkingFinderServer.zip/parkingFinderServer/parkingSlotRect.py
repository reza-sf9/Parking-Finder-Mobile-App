# Developed by Reza Saadati Fard
# Date: Dec, 2023

# this code get areas of parking slots from a video
# you should select 4 points for each parking slot
# then the selected coordinates will be shown in the command window
# you should use these coordinates to define parking slots in the main code (e.g. areaB1 info comes from here)
# after selecting 4 points (for eeach rectangular) and selecting all desired parking lots, press 'q' to exit the program

import cv2

videoStatus = 1 # 1 for local test video - 2 for live streaming from Iphone by using Iriun Webcam app


# Function to handle mouse click events
# this function gets called whenever a mouse event occurs
# if 4 points are clicked, they are stored in a list
def click_event(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        cv2.circle(img, (x, y), 3, (0, 255, 0), -1)
        points.append((x, y))
        if len(points) == 4:
            parking_slots.append(points.copy())

            print(points)
            points.clear()
        cv2.imshow('frame', img)

# Load video
# load test video
if videoStatus == 1:
    cap = cv2.VideoCapture('unity_test.mov')
 # get vidieo from camera
elif videoStatus == 2:
    cap = cv2.VideoCapture(1)



# Get video from iphone
# cap = cv2.VideoCapture(1)

# Get video from camera
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Capture the first frame
ret, img = cap.read()
# img = cv2.resize(img, (1280,720))

# Check if frame is captured
if not ret:
    print("Failed to capture frame")
    cap.release()
    exit()

# Initialize list to store parking slot coordinates
parking_slots = []
points = []

# Create a window and set a mouse callback function
cv2.imshow('frame', img)
cv2.setMouseCallback('frame', click_event)

# Wait until 'q' is pressed
while True:
    if cv2.waitKey(1) & 0xFF == ord('q'):

        break


